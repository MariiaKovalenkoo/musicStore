User: `markL`
Password: `mark1234!`
- First Name: Mark
- Last Name: Lee
- Role: Sales

User: `aliceS`
Password: `alice1234!`
- First Name: Alice
- Last Name: Smith
- Role: Manager

User: `davidBr`
Password: `user3456!`
- First Name: David
- Last Name: Brown
- Role: Manager

User: `BobJn`
Password: `user4536!`
- First Name: Bob
- Last Name: Johnson
- Role: Sales