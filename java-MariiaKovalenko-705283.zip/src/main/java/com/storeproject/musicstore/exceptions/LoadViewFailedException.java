package com.storeproject.musicstore.exceptions;

public class LoadViewFailedException extends Exception {
    public LoadViewFailedException(String message) {
        super(message);
    }
}